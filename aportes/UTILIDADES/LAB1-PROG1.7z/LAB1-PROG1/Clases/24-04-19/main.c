#include <stdio.h>
#include <stdlib.h>

int main()
{

    return 0;
}
