int obtenerMaximo(int x , int y , int z);
