int obtenerNumero(void);
char obtenerSexo(void);
