#include <stdio.h>
#include <stdlib.h>

#define TAM 5

int main(){

	char vec[TAM];

	for(int 0; i < TAM; i++){

        vec[i] = 'e';
	}

	for(int i = 0; i < TAM){


	}

	return 0;
}
