#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main()
{
    int vec[10] = {10, 2, 3, 4, 5,6 , 9 , 9, 4, 1};

    for(int i = 0; i < 10 ; i++)
    {
        printf("Numero del Vector %d", vec[i]);
    }


    return 0;
}
