int obtenerNumero(void);
