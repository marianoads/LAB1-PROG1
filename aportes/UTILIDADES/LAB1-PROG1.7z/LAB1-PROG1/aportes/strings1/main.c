#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    /*char cad1[20] = "HOLAAAAA";
    char cad2[20] = "HolA";
    if(strcmp(cad1, cad2) == 0){
        printf("son iguales\n");
    }
    else if(strcmp(cad1, cad2) > 0){
        printf("cad1 es mayor");
    }
    else{
        printf("cad2 es mayor");
    }*/

   /* char clave[20] = "123";
    printf("ingresa la clave ");
    fgets(clave, sizeof(clave)-2, stdin);
    clave[strlen(clave)-1] = '\0';
    if(strcmp(clave, "123")== 0)
        printf("clave correcta\n");
    else
        printf("clave incorrecta");*/

        /*char texto1[20];
    char texto2[20];
    printf("\nIngrese unapalabra: ");
    gets(texto1);
    strcpy(texto2,texto1);
    printf("Se ingreso:%s la copia es:%s",texto1,texto2);*/

    char cad[20];
    char cad1[20];
    printf("Ingrese una palabra\n");
    fgets(cad, sizeof(cad)-2,stdin);
    cad[strlen(cad)-1] = '\0';
    //gets(cad);
    //scanf("%s", cad);
    printf("\n");
    printf("Ingrese una palabra\n");
    fgets(cad1, sizeof(cad1)-2,stdin);
    cad1[strlen(cad1)-1] = '\0';
    //gets(cad1);
    //scanf("%s", cad1);
    printf("\n");
    printf("len cad %d len cad1 %d\n",strlen(cad),strlen(cad1));
    printf("cad %s cad1 %s \n",cad ,cad1);
    printf("size of cad %d cad1 %d", sizeof(cad), sizeof(cad1));
    return 0;
}
